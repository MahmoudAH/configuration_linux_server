Project Description

Take a baseline installation of a Linux distribution on a virtual machine and prepare it to host your web applications, to include installing updates, securing it from a number of attack vectors and installing/configuring web and database servers

Walkthrough:
-Public IP: http://13.58.188.213/
-SSH PORT: 2200
-Catalog App URL using DNS domain: http://ec2-13-58-188-213
.us-west-2.compute.amazonaws.com/
-Grader Passphrase for SSH login: realmadrid


1-Update all currently installed packages:
.Find updates: sudo apt-get update
.Install updates: sudo apt-get upgrade 

2-Configure the Uncomplicated Firewall (UFW) to only allow incoming connections for SSH (port 2200), HTTP (port 80), and NTP (port 123):
.Check UFW status to make sure its inactive: sudo ufw status
.Deny all incoming by default: sudo ufw default deny incoming
.Allow outgoing by default: sudo ufw default allow outgoing
.Allow SSH: sudo ufw allow ssh
.Allow SSH on port 2200: sudo ufw allow 2200/tcp
.Allow HTTP on port 80: sudo ufw allow 80/tcp
.Allow NTP on port 123: sudo ufw allow 123/udp
.Turn on firewall: sudo ufw enable

3-Make sure the timezone is set to UTC:
.Ceck that the timezone is set to UTC: sudo dpkg-reconfigure tzdata
It should default to UTC.

4-Creating and securing the grader account with SSH and sudo access
.Enter: sudo adduser grader
.Give grader a password of: 12345
.Install finger: apt-get install finger
.Check grader account with finger: finger grader
.Give the grader the permission to sudo:
.Create a sudoers.d file for grader: sudo nano /etc/suoders.d/grader
.Inside the file add: grader ALL=(ALL) NOPASSWD:ALL
.Save file: (nano: ctrl+x, Y, Enter)

This gives grader the same level of admin access as the Ubuntu account which is created when the cloud instance of Ubuntu is built.

5-Create SSH keys and copy the public key to the server manually:
.On your local machine generate SSH key pair with: ssh-keygen
.I added a passphrase for security: realmadrid

.Save the public and private SSH keys in in the default SSH directory: C:\Users\Mahmoud\.ssh (in my case.)

.My public and private key files are:id_rsa.pub and id_rsa
.Login into grader account using password set during user     creation: ssh grader@13.58.188.213 -p 2200

.Make .ssh directory: mkdir .ssh
.Make file to store public key: touch .ssh/authorized_keys
.On your local machine read and copy contents of the public key: cat ~/.ssh/id_rsa.pub then copy the key to the clipboard.

.Login to the grader account and paste contents of clipboard into the authorized_keys file: nano /home/grader/.ssh/authorized_keys then paste contents(ctr+v).

.Save file: (nano: ctrl+x, Y, Enter)

.Set permissions for the directory and file: chmod 700 .ssh and chmod 644 .ssh/authorized_keys

.Change PasswordAuthentication from yes back to no in the sshd_config file: nano /etc/ssh/sshd_config

.Save file(nano: ctrl+x, Y, Enter)
Login with the corresponding private key: ssh grader@13.58.188.213 -p 2200 -i ~/.ssh/id_rsa

6-Setting up and configuring the Apache HTTP server and the Python wsgi interface

Here we install the Apache web server and make sure the default Apache web page can be accessed on port 80. The Apache and wsgi configurations are then added using these steps:

.Install Apache web server: sudo apt-get install apache2
.Install mod_wsgi: sudo apt-get install libapache2-mod-wsgi
.Configure Apache to handle requests using the WSGI module: sudo nano /etc/apache2/sites-enabled/000-default.conf
Add: "WSGIScriptAlias / /var/www/html/myapp.wsgi" before </VirtualHost> closing line
Save file: (nano: ctrl+x, Y, Enter)
.Enable mod_wsgi with: sudo a2enmod wsgi
.Restart Apache: sudo apache2ctl restart
.Install python-dev package: sudo apt-get install python-dev

7-Setting up PostgreSQL server
The following steps get the catalog database up and running:

.sudo apt-get install libpq-dev python-dev
.sudo apt-get install postgresql postgresql-contrib
.sudo su - postgres
.psql
.CREATE USER catalog WITH PASSWORD 'password';
.ALTER USER catalog CREATEDB;
.CREATE DATABASE catalog WITH OWNER catalog;
.\c catalog
.REVOKE ALL ON SCHEMA public FROM public;
.GRANT ALL ON SCHEMA public TO catalog;
.\q
.exit

After you have installed the catalog app below, make sure that you:

Change create engine line in your __init__.py and database_setup.py to: engine = create_engine('postgresql://catalog:password@localhost/catalog')

Make sure no remote connections to the database are allowed: sudo nano /etc/postgresql/9.5/main/pg_hba.conf Should produce output that looks like this:
local   all             postgres                                peer
local   all             all                                     peer
host    all             all             127.0.0.1/32            md5
host    all             all             ::1/128                 md5

8-Installing the Catalog app code and preparing it for deployment

.Install git using: sudo apt-get install git

.cd /var/www
.sudo mkdir catalog
.Change owner of the newly created catalog folder :sudo chown -R grader:grader catalog
.cd /catalog
.Clone your project from github git clone https://github.com/MoKhaled3003/MoRestaurants/
.Create a catalog.wsgi file, then place it in the /var/www/catalog directory.

.Run this: sudo nano /var/www/catalog/catalog.wsgi

.Paste the code below and save the file (nano: ctrl+x, Y, Enter):
"""
#!/usr/bin/python
import sys
import logging
logging.basicConfig(stream=sys.stderr)
sys.path.insert(0,"/var/www/catalog/")
from catalog import app as application
application.secret_key = 'lees_secret_key'
"""

9-Install virtual environment
.Install the virtual environment sudo pip install virtualenv
.Create a new virtual environment with sudo virtualenv venv
.Activate the virutal environment source venv/bin/activate
.Change permissions sudo chmod -R 777 venv

10-Install Flask and other dependencies
.Install pip with sudo apt-get install python-pip
.Install Flask pip install Flask
.Install other project dependencies sudo pip install httplib2 oauth2client sqlalchemy psycopg2 sqlalchemy_utils

11-Update path of client_secrets.json file

.nano __init__.py
.Change client_secrets.json path to /var/www/catalog/catalog/client_secrets.json

****
12-Run this: sudo nano /etc/apache2/sites-available/catalog.conf

Paste the code below and save the file (nano: ctrl+x, Y, Enter):


<VirtualHost *:80>
    ServerName http:13.58.188.213
    ServerAlias ec2-13-58-188-213.us- east-2.compute.amazonaws.com

    ServerAdmin admin@13.58.188.213
    WSGIDaemonProcess catalog python-    path=/var/www/catalog:/var/www/catalog/ven$
    WSGIProcessGroup catalog
    WSGIScriptAlias / /var/www/catalog/myapp.wsgi
    <Directory /var/www/catalog/catalog/>
        Order allow,deny
        Allow from all
    </Directory>
    Alias /static /var/www/catalog/catalog/static
    <Directory /var/www/catalog/catalog/static/>
        Order allow,deny
        Allow from all
    </Directory>
    ErrorLog ${APACHE_LOG_DIR}/error.log
    LogLevel warn
    Allow from all
    </Directory>
    Alias /static /var/www/catalog/catalog/static
    <Directory /var/www/catalog/catalog/static/>
        Order allow,deny
        Allow from all
    </Directory>
    ErrorLog ${APACHE_LOG_DIR}/error.log
    LogLevel warn
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>

****
.Enable the virtual host :sudo a2ensite catalog


13-Then restart apache: sudo service apache2 restart

14-Visit site at http://13.58.188.213/
****
References

1-https://www.digitalocean.com/community/tutorials/how-to-secure-postgresql-on-an-ubuntu-vps
2-https://help.ubuntu.com/community/UbuntuTime#Using_the_Command_Line_.28terminal.29

